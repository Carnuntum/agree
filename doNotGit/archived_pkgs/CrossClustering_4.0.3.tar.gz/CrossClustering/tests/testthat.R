library(testthat)
library(CrossClustering)

test_check("CrossClustering")
